/**
 * Google Maps Image Downloader - Content Script v1.3
 *
 * Signal nhận biết URL có ảnh:
 *   - URL chứa "!6shttps" → segment !6s (string thứ 6) chứa link ảnh thực sự
 *   - Áp dụng cho cả ảnh địa điểm (googleusercontent) lẫn Street View (streetviewpixels-pa)
 */

(function () {
  'use strict';

  const ICON_URL = chrome.runtime.getURL('icon-48.png');

  const BUTTON_ID   = 'gmid-get-image-btn';
  const WEBSITE_URL = 'https://downloadmapimage.com/';

  // ─── Chạy trên trang downloadmapimage.com: auto-fill & submit ──────────────
  function runOnDownloadSite() {
    var params  = new URLSearchParams(window.location.search);
    var mapsUrl = params.get('u');
    if (!mapsUrl) return;

    function tryAutoFill(attempts) {
      var textarea = document.getElementById('gic-url');
      var btn      = document.getElementById('gic-btn-extract');

      if (textarea && btn) {
        textarea.value = mapsUrl;
        textarea.dispatchEvent(new Event('input',  { bubbles: true }));
        textarea.dispatchEvent(new Event('change', { bubbles: true }));
        setTimeout(function () { btn.click(); }, 300);
      } else if (attempts > 0) {
        setTimeout(function () { tryAutoFill(attempts - 1); }, 500);
      }
    }

    tryAutoFill(20);
  }

  // ─── Detect URL ảnh ─────────────────────────────────────────
  function urlHasImage(url) {
    return /!6shttps/i.test(url);
  }

  // ─── Build button "Get Image" — style giống hệt Get Subtitles ──────────────
  function buildButton() {
    // destUrl sẽ được tính tại thời điểm click (không dùng currentUrl nữa)

    // Wrapper ngoài
    var wrapper = document.createElement('div');
    wrapper.id = BUTTON_ID;
    wrapper.style.cssText = [
      'position:fixed',
      'top:70px',
      'right:20px',
      'z-index:2147483647',
      'height:22px',
      'display:flex',
      'align-items:center',
      'pointer-events:auto',
    ].join(';');

    // Link chính — style giống Get Subtitles (downloadyoutubesubtitles.com)
    var link   = document.createElement('a');
    link.id    = BUTTON_ID + '-link';
    link.href  = '#';
    // Lấy URL tại thời điểm click — luôn chính xác dù người dùng vừa xoay Street View
    link.addEventListener('click', function (e) {
      e.preventDefault();
      var destUrl = WEBSITE_URL + '?u=' + encodeURIComponent(window.location.href);
      chrome.runtime.sendMessage({ action: 'openOrReuseTab', url: destUrl });
    });
    link.target = '_blank';
    link.rel    = 'noopener noreferrer';
    link.title  = 'Download thumbnail image from this Google Maps location via DownloadMapImage.com';

    link.style.cssText = [
      'display:inline-flex',
      'align-items:center',
      'vertical-align:middle',
      'font-weight:bold',
      'font-size:1.6em',
      'text-decoration:none',
      'color:#fff',
      'padding-left:10px',
      'cursor:pointer',
      'white-space:nowrap',
      'text-shadow:2px 0px 2px black,0px 2px 2px black,-2px 0px 2px black,0px -2px 2px black',
      'line-height:22px',
      'background:transparent',
      'border:none',
      'outline:none',
	  'border-radius: 40px',
	  'height: 40px',
	  'background: rgba(0, 0, 0, 0.6)',
	  'padding: 0 10px 0 10px',
    ].join(';');

    // Icon từ extension (icon-48.png)
    var img   = document.createElement('img');
    img.src   = ICON_URL;
    img.alt   = '';
    img.style.cssText = [
      'width:22px',
      'height:22px',
      'margin-right:5px',
      'vertical-align:middle',
      'display:inline-block',
    ].join(';');

    // Text
    var span         = document.createElement('span');
    span.style.cssText = 'line-height:22px;vertical-align:middle;font-size:22px;';
    span.textContent = 'Get Image';

    link.appendChild(img);
    link.appendChild(span);
    wrapper.appendChild(link);
    return wrapper;
  }

  // ─── Inject / update / remove button theo URL hiện tại ────────────────────
  function updateButton() {
    var url      = window.location.href;
    var existing = document.getElementById(BUTTON_ID);

    if (urlHasImage(url)) {
      // Button đã tồn tại thì giữ nguyên — href sẽ được lấy lúc click
      if (!existing && document.body) {
        document.body.appendChild(buildButton());
      }
    } else {
      if (existing) existing.remove();
    }
  }

  // ─── SPA navigation watcher — continuous interval ────────────────────────
  // Vấn đề gốc: Maps đôi khi dùng replaceState nhiều bước (xóa !6s rồi thêm
  // lại), hoặc dùng Navigation API mới không qua history.pushState. Mọi cách
  // dựa vào "trigger rồi poll" đều có thể bỏ sót bước cuối cùng.
  //
  // Giải pháp: interval chạy liên tục mỗi 300ms, chỉ gọi updateButton() khi
  // URL thực sự thay đổi. Chi phí cực thấp (chỉ so sánh 1 string/300ms).
  var _watchedHref = window.location.href;

  setInterval(function () {
    var href = window.location.href;
    if (href !== _watchedHref) {
      _watchedHref = href;
      updateButton();
    }
  }, 300);

  // ─── Entry point ──────────────────────────────────────────────────────────
  var hostname = window.location.hostname;

  if (/downloadmapimage\.com/i.test(hostname)) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', runOnDownloadSite);
    } else {
      runOnDownloadSite();
    }

  } else if (/google\.com/i.test(hostname)) {
    // Chạy ngay lập tức + 1 lần retry sau 500ms phòng Maps load lazy
    if (document.body) {
      updateButton();
    } else {
      document.addEventListener('DOMContentLoaded', updateButton);
    }
    setTimeout(updateButton, 500);
  }

})();
