// Background service worker — đổi icon màu theo tab đang active
// Màu đỏ (active) khi ở google.com/maps, màu xám (inactive) ở trang khác

const ICON_ACTIVE = {
  '16': 'icon-16.png',
  '32': 'icon-32.png',
  '48': 'icon-48.png',
  '96': 'icon-96.png',
  '128': 'icon-128.png',
};

const ICON_GRAY = {
  '16': 'icon-16-gray.png',
  '32': 'icon-32-gray.png',
  '48': 'icon-48-gray.png',
  '96': 'icon-96-gray.png',
  '128': 'icon-128-gray.png',
};

function isGoogleMaps(url) {
  try {
    return /^https:\/\/www\.google\.com\/maps/.test(url);
  } catch (e) {
    return false;
  }
}

function updateIcon(tabId, url) {
  var icons = isGoogleMaps(url) ? ICON_ACTIVE : ICON_GRAY;
  chrome.action.setIcon({ tabId: tabId, path: icons });
}

// Khi chuyển tab
chrome.tabs.onActivated.addListener(function(activeInfo) {
  chrome.tabs.get(activeInfo.tabId, function(tab) {
    if (tab && tab.url) updateIcon(tab.id, tab.url);
  });
});

// Khi tab navigate (URL thay đổi)
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  if (changeInfo.url) {
    updateIcon(tabId, changeInfo.url);
  }
});

// Khi mới mở Chrome / service worker khởi động: set icon cho tab hiện tại
chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
  if (tabs[0] && tabs[0].url) {
    updateIcon(tabs[0].id, tabs[0].url);
  }
});

// Mở hoặc tái sử dụng tab downloadmapimage.com
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.action !== 'openOrReuseTab') return;

  var destUrl = message.url;

  // Tìm tab đã mở ở downloadmapimage.com (bất kỳ path nào)
  chrome.tabs.query({ url: 'https://downloadmapimage.com/*' }, function(tabs) {
    if (tabs && tabs.length > 0) {
      // Đã có tab → cập nhật URL và focus vào tab đó
      var tab = tabs[0];
      chrome.tabs.update(tab.id, { url: destUrl, active: true });
      chrome.windows.update(tab.windowId, { focused: true });
    } else {
      // Chưa có tab → mở tab mới
      chrome.tabs.create({ url: destUrl });
    }
  });
});
