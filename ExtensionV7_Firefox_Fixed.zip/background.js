// Background script — đổi icon màu theo tab đang active
// Màu đỏ (active) khi ở google.com/maps, màu xám (inactive) ở trang khác
// Firefox MV2: dùng browser.* API với WebExtensions polyfill pattern

const ICON_ACTIVE = {
  '16': 'icon-16.png',
  '32': 'icon-32.png',
  '48': 'icon-48.png',
  '96': 'icon-96.png',
  '128': 'icon-128.png',
};

const ICON_GRAY = {
  '16': 'icon-16-gray.png',
  '32': 'icon-32-gray.png',
  '48': 'icon-48-gray.png',
  '96': 'icon-96-gray.png',
  '128': 'icon-128-gray.png',
};

function isGoogleMaps(url) {
  try {
    return /^https:\/\/www\.google\.com\/maps/.test(url);
  } catch (e) {
    return false;
  }
}

function isDownloadSite(url) {
  try {
    return /^https:\/\/downloadmapimage\.com/.test(url);
  } catch (e) {
    return false;
  }
}

function updateIcon(tabId, url) {
  var icons = isGoogleMaps(url) ? ICON_ACTIVE : ICON_GRAY;
  browser.browserAction.setIcon({ tabId: tabId, path: icons });
}

// Fix 3: Set để track các tab đang trong quá trình inject,
// tránh race condition khi onActivated + onUpdated fire gần nhau.
var _injectingTabs = new Set();

// Inject content script vào tab nếu chưa có.
// Kiểm tra flag __gmidContentScriptLoaded trước để tránh chạy 2 lần.
function ensureContentScript(tabId) {
  // Nếu đang trong quá trình inject tab này rồi thì bỏ qua
  if (_injectingTabs.has(tabId)) return;
  _injectingTabs.add(tabId);

  browser.tabs.executeScript(tabId, {
    code: 'window.__gmidContentScriptLoaded === true;'
  }).then(function(results) {
    if (!results || !results[0]) {
      return browser.tabs.executeScript(tabId, { file: 'content.js' });
    }
  }).catch(function() {
    // Tab chưa sẵn sàng hoặc không có quyền — bỏ qua
  }).then(function() {
    // Xóa khỏi Set sau khi inject xong (dù thành công hay thất bại)
    _injectingTabs.delete(tabId);
  });
}

// Inject vào tất cả tab Maps/DownloadSite đang mở sẵn.
// Gọi ở 3 thời điểm để bao phủ mọi trường hợp (xem bên dưới).
function injectIntoMatchingTabs() {
  browser.tabs.query({}).then(function(tabs) {
    tabs.forEach(function(tab) {
      if (!tab.url) return;
      updateIcon(tab.id, tab.url);
      if (isGoogleMaps(tab.url) || isDownloadSite(tab.url)) {
        ensureContentScript(tab.id);
      }
    });
  }).catch(function() {});
}

// ─── Khi chuyển tab ───────────────────────────────────────────────────────────
browser.tabs.onActivated.addListener(function(activeInfo) {
  browser.tabs.get(activeInfo.tabId).then(function(tab) {
    if (!tab || !tab.url) return;
    updateIcon(tab.id, tab.url);
    if (isGoogleMaps(tab.url) || isDownloadSite(tab.url)) {
      ensureContentScript(tab.id);
    }
  }).catch(function() {});
});

// ─── Khi tab navigate hoặc load xong ─────────────────────────────────────────
browser.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  // Fix 2: ưu tiên changeInfo.url (URL mới nhất khi navigate),
  // fallback tab.url (URL hiện tại của tab object).
  var url = changeInfo.url || tab.url;
  if (url) updateIcon(tabId, url);

  // Chờ status === 'complete' để DOM chắc chắn sẵn sàng trước khi inject.
  // Dùng url đã resolve ở trên để nhất quán.
  if (changeInfo.status === 'complete' && url) {
    if (isGoogleMaps(url) || isDownloadSite(url)) {
      ensureContentScript(tabId);
    }
  }
});

// Khi tab bị đóng: xóa khỏi _injectingTabs để tránh Set tích lũy rác
browser.tabs.onRemoved.addListener(function(tabId) {
  _injectingTabs.delete(tabId);
});

// ─── 3 thời điểm khởi động — bao phủ mọi trường hợp ─────────────────────────
//
//   1. Chạy ngay (top-level): bắt reload extension qua about:debugging —
//      onInstalled không fire khi reload thủ công, nhưng background script
//      được load lại và top-level code chạy ngay.
//
//   2. onInstalled: cài extension lần đầu hoặc update lên version mới.
//
//   3. onStartup: Firefox khởi động lại với các tab đã được restore từ
//      session trước — onInstalled không fire trong trường hợp này.
//
injectIntoMatchingTabs();
browser.runtime.onInstalled.addListener(injectIntoMatchingTabs);
browser.runtime.onStartup.addListener(injectIntoMatchingTabs);

// ─── Mở hoặc tái sử dụng tab downloadmapimage.com ────────────────────────────
browser.runtime.onMessage.addListener(function(message, sender) {
  if (message.action !== 'openOrReuseTab') return;

  var destUrl = message.url;

  browser.tabs.query({ url: 'https://downloadmapimage.com/*' }).then(function(tabs) {
    if (tabs && tabs.length > 0) {
      var tab = tabs[0];
      browser.tabs.update(tab.id, { url: destUrl, active: true });
      browser.windows.update(tab.windowId, { focused: true });
    } else {
      browser.tabs.create({ url: destUrl });
    }
  }).catch(function() {
    browser.tabs.create({ url: destUrl });
  });
});
