/**
 * Google Maps Image Downloader - Content Script v1.3
 * Firefox version
 *
 * Signal nhận biết URL có ảnh:
 *   - URL chứa "!6shttps" → segment !6s (string thứ 6) chứa link ảnh thực sự
 *   - Áp dụng cho cả ảnh địa điểm (googleusercontent) lẫn Street View (streetviewpixels-pa)
 */

(function () {
  'use strict';

  // Guard: tránh inject 2 lần (background có thể gọi executeScript nhiều lần)
  if (window.__gmidContentScriptLoaded) return;
  window.__gmidContentScriptLoaded = true;

  const ICON_URL    = browser.runtime.getURL('icon-48.png');
  const BUTTON_ID   = 'gmid-get-image-btn';
  const WEBSITE_URL = 'https://downloadmapimage.com/';

  // ─── Chạy trên trang downloadmapimage.com: auto-fill & submit ──────────────
  function runOnDownloadSite() {
    var params  = new URLSearchParams(window.location.search);
    var mapsUrl = params.get('u');
    if (!mapsUrl) return;

    function tryAutoFill(attempts) {
      var textarea = document.getElementById('gic-url');
      var btn      = document.getElementById('gic-btn-extract');

      if (textarea && btn) {
        textarea.value = mapsUrl;
        textarea.dispatchEvent(new Event('input',  { bubbles: true }));
        textarea.dispatchEvent(new Event('change', { bubbles: true }));
        setTimeout(function () { btn.click(); }, 300);
      } else if (attempts > 0) {
        setTimeout(function () { tryAutoFill(attempts - 1); }, 500);
      }
    }

    tryAutoFill(20);
  }

  // ─── Detect URL ảnh ──────────────────────────────────────────────────────
  function urlHasImage(url) {
    return /!6shttps/i.test(url);
  }

  // ─── Build button "Get Image" ─────────────────────────────────────────────
  function buildButton() {
    var wrapper = document.createElement('div');
    wrapper.id = BUTTON_ID;
    wrapper.style.cssText = [
      'position:fixed',
      'top:70px',
      'right:20px',
      'z-index:2147483647',
      'height:22px',
      'display:flex',
      'align-items:center',
      'pointer-events:auto',
    ].join(';');

    var link = document.createElement('a');
    link.id  = BUTTON_ID + '-link';
    link.href = '#';
    link.addEventListener('click', function (e) {
      e.preventDefault();
      var destUrl = WEBSITE_URL + '?u=' + encodeURIComponent(window.location.href);
      browser.runtime.sendMessage({ action: 'openOrReuseTab', url: destUrl }).catch(function() {
        // Fallback: background không phản hồi → mở tab mới trực tiếp
        window.open(destUrl, '_blank', 'noopener,noreferrer');
      });
    });
    link.target = '_blank';
    link.rel    = 'noopener noreferrer';
    link.title  = 'Download thumbnail image from this Google Maps location via DownloadMapImage.com';

    link.style.cssText = [
      'display:inline-flex',
      'align-items:center',
      'vertical-align:middle',
      'font-weight:bold',
      'font-size:1.6em',
      'text-decoration:none',
      'color:#fff',
      'padding-left:10px',
      'cursor:pointer',
      'white-space:nowrap',
      'text-shadow:2px 0px 2px black,0px 2px 2px black,-2px 0px 2px black,0px -2px 2px black',
      'line-height:22px',
      'background:transparent',
      'border:none',
      'outline:none',
      'border-radius:40px',
      'height:40px',
      'background:rgba(0,0,0,0.6)',
      'padding:0 10px 0 10px',
    ].join(';');

    var img = document.createElement('img');
    img.src = ICON_URL;
    img.alt = '';
    img.style.cssText = [
      'width:22px',
      'height:22px',
      'margin-right:5px',
      'vertical-align:middle',
      'display:inline-block',
    ].join(';');

    var span = document.createElement('span');
    span.style.cssText = 'line-height:22px;vertical-align:middle;font-size:22px;';
    span.textContent = 'Get Image';

    link.appendChild(img);
    link.appendChild(span);
    wrapper.appendChild(link);
    return wrapper;
  }

  // ─── Inject / update / remove button theo URL hiện tại ───────────────────
  function updateButton() {
    var url      = window.location.href;
    var existing = document.getElementById(BUTTON_ID);

    if (urlHasImage(url)) {
      if (!existing && document.body) {
        document.body.appendChild(buildButton());
      }
    } else {
      if (existing) existing.remove();
    }
  }

  // ─── SPA navigation watcher — interval 300ms ──────────────────────────────
  var _watchedHref = '';  // Khởi tạo rỗng để lần đầu luôn trigger updateButton()

  setInterval(function () {
    var href = window.location.href;
    if (href !== _watchedHref) {
      _watchedHref = href;
      updateButton();
    }
  }, 300);

  // ─── Entry point ──────────────────────────────────────────────────────────
  var hostname = window.location.hostname;

  if (/downloadmapimage\.com/i.test(hostname)) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', runOnDownloadSite);
    } else {
      runOnDownloadSite();
    }

  } else if (/google\.com/i.test(hostname)) {
    // updateButton() được gọi qua interval ngay chu kỳ đầu tiên (300ms)
    // vì _watchedHref = '' sẽ khác với URL thực → luôn trigger
    // Nhưng cũng gọi thêm ngay lập tức để không phải chờ 300ms
    if (document.body) {
      updateButton();
    } else {
      document.addEventListener('DOMContentLoaded', updateButton);
    }
  }

})();
