// Background service worker — đổi icon màu theo tab đang active
// Màu đỏ (active) khi ở google.com/maps, màu xám (inactive) ở trang khác
// Opera-compatible: sử dụng chrome API (Opera hỗ trợ chrome.* namespace)

// Opera polyfill: một số phiên bản Opera expose 'opr' thay vì 'chrome'
// Đảm bảo luôn dùng đúng namespace
const _api = (typeof chrome !== 'undefined' && chrome.runtime)
  ? chrome
  : (typeof browser !== 'undefined' ? browser : null);

if (!_api) {
  console.error('[GMID] Không tìm thấy Extension API (chrome/browser).');
}

const ICON_ACTIVE = {
  '16': 'icon-16.png',
  '32': 'icon-32.png',
  '48': 'icon-48.png',
  '96': 'icon-96.png',
  '128': 'icon-128.png',
};

const ICON_GRAY = {
  '16': 'icon-16-gray.png',
  '32': 'icon-32-gray.png',
  '48': 'icon-48-gray.png',
  '96': 'icon-96-gray.png',
  '128': 'icon-128-gray.png',
};

function isGoogleMaps(url) {
  try {
    return /^https:\/\/www\.google\.com\/maps/.test(url);
  } catch (e) {
    return false;
  }
}

function updateIcon(tabId, url) {
  if (!_api) return;
  var icons = isGoogleMaps(url) ? ICON_ACTIVE : ICON_GRAY;
  // Opera đôi khi cần try/catch khi tab đã đóng
  try {
    _api.action.setIcon({ tabId: tabId, path: icons });
  } catch (e) {
    // tab đã đóng hoặc không còn tồn tại — bỏ qua
  }
}

// Khi chuyển tab
_api.tabs.onActivated.addListener(function(activeInfo) {
  _api.tabs.get(activeInfo.tabId, function(tab) {
    // Kiểm tra lastError để tránh lỗi "No tab with id" trên Opera
    if (_api.runtime.lastError) return;
    if (tab && tab.url) updateIcon(tab.id, tab.url);
  });
});

// Khi tab navigate (URL thay đổi)
_api.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  if (changeInfo.url) {
    updateIcon(tabId, changeInfo.url);
  }
});

// Khi mới mở Opera / service worker khởi động: set icon cho tab hiện tại
_api.tabs.query({ active: true, currentWindow: true }, function(tabs) {
  if (_api.runtime.lastError) return;
  if (tabs[0] && tabs[0].url) {
    updateIcon(tabs[0].id, tabs[0].url);
  }
});

// Mở hoặc tái sử dụng tab downloadmapimage.com
_api.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.action !== 'openOrReuseTab') return;

  var destUrl = message.url;

  // Tìm tab đã mở ở downloadmapimage.com (bất kỳ path nào)
  _api.tabs.query({ url: 'https://downloadmapimage.com/*' }, function(tabs) {
    if (_api.runtime.lastError) {
      // Opera đôi khi báo lỗi khi query URL pattern — fallback: mở tab mới
      _api.tabs.create({ url: destUrl });
      return;
    }
    if (tabs && tabs.length > 0) {
      // Đã có tab → cập nhật URL và focus vào tab đó
      var tab = tabs[0];
      _api.tabs.update(tab.id, { url: destUrl, active: true });
      _api.windows.update(tab.windowId, { focused: true });
    } else {
      // Chưa có tab → mở tab mới
      _api.tabs.create({ url: destUrl });
    }
  });
});
