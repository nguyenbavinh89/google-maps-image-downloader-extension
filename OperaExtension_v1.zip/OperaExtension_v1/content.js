/**
 * Google Maps Image Downloader - Content Script v1.3 (Opera Edition)
 *
 * Opera-compatible: Sử dụng cả chrome.* và browser.* API
 * Fix chính: Opera inject content script nhưng chrome.runtime.getURL()
 * có thể không hoạt động đúng — dùng polyfill _rt để đảm bảo tương thích.
 *
 * Signal nhận biết URL có ảnh:
 *   - URL chứa "!6shttps" → segment !6s (string thứ 6) chứa link ảnh thực sự
 *   - Áp dụng cho cả ảnh địa điểm (googleusercontent) lẫn Street View (streetviewpixels-pa)
 */

(function () {
  'use strict';

  // ─── Opera / Chrome API polyfill ────────────────────────────────────────────
  // Opera hỗ trợ cả chrome.* và browser.* — ưu tiên chrome.* để nhất quán.
  // Nếu không có chrome.runtime (hiếm), fallback sang browser.*
  var _rt = null;
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL) {
    _rt = chrome.runtime;
  } else if (typeof browser !== 'undefined' && browser.runtime && browser.runtime.getURL) {
    _rt = browser.runtime;
  }

  // Nếu không có runtime API → không phải context extension → thoát
  if (!_rt) return;

  // ─── Lấy ICON_URL an toàn ───────────────────────────────────────────────────
  var ICON_URL = null;
  try {
    ICON_URL = _rt.getURL('icon-48.png');
  } catch (e) {
    // Một số build Opera cũ có thể throw — dùng fallback không có icon
    ICON_URL = '';
  }

  const BUTTON_ID   = 'gmid-get-image-btn';
  const WEBSITE_URL = 'https://downloadmapimage.com/';

  // ─── Chạy trên trang downloadmapimage.com: auto-fill & submit ──────────────
  function runOnDownloadSite() {
    var params  = new URLSearchParams(window.location.search);
    var mapsUrl = params.get('u');
    if (!mapsUrl) return;

    function tryAutoFill(attempts) {
      var textarea = document.getElementById('gic-url');
      var btn      = document.getElementById('gic-btn-extract');

      if (textarea && btn) {
        textarea.value = mapsUrl;
        textarea.dispatchEvent(new Event('input',  { bubbles: true }));
        textarea.dispatchEvent(new Event('change', { bubbles: true }));
        setTimeout(function () { btn.click(); }, 300);
      } else if (attempts > 0) {
        setTimeout(function () { tryAutoFill(attempts - 1); }, 500);
      }
    }

    tryAutoFill(20);
  }

  // ─── Detect URL ảnh ─────────────────────────────────────────
  function urlHasImage(url) {
    return /!6shttps/i.test(url);
  }

  // ─── Build button "Get Image" ───────────────────────────────────────────────
  function buildButton() {
    // Wrapper ngoài
    var wrapper = document.createElement('div');
    wrapper.id = BUTTON_ID;
    wrapper.style.cssText = [
      'position:fixed',
      'top:70px',
      'right:20px',
      'z-index:2147483647',
      'height:22px',
      'display:flex',
      'align-items:center',
      'pointer-events:auto',
    ].join(';');

    // Link chính
    var link   = document.createElement('a');
    link.id    = BUTTON_ID + '-link';
    link.href  = '#';

    // Lấy URL tại thời điểm click — luôn chính xác dù người dùng vừa xoay Street View
    link.addEventListener('click', function (e) {
      e.preventDefault();
      var destUrl = WEBSITE_URL + '?u=' + encodeURIComponent(window.location.href);

      // Gửi message đến background — dùng _rt để tương thích Opera
      try {
        _rt.sendMessage({ action: 'openOrReuseTab', url: destUrl });
      } catch (err) {
        // Fallback nếu background không phản hồi: mở tab trực tiếp
        window.open(destUrl, '_blank', 'noopener,noreferrer');
      }
    });

    link.target = '_blank';
    link.rel    = 'noopener noreferrer';
    link.title  = 'Download thumbnail image from this Google Maps location via DownloadMapImage.com';

    link.style.cssText = [
      'display:inline-flex',
      'align-items:center',
      'vertical-align:middle',
      'font-weight:bold',
      'font-size:1.6em',
      'text-decoration:none',
      'color:#fff',
      'padding-left:10px',
      'cursor:pointer',
      'white-space:nowrap',
      'text-shadow:2px 0px 2px black,0px 2px 2px black,-2px 0px 2px black,0px -2px 2px black',
      'line-height:22px',
      'background:transparent',
      'border:none',
      'outline:none',
      'border-radius:40px',
      'height:40px',
      'background:rgba(0,0,0,0.6)',
      'padding:0 10px 0 10px',
    ].join(';');

    // Icon từ extension (icon-48.png)
    if (ICON_URL) {
      var img   = document.createElement('img');
      img.src   = ICON_URL;
      img.alt   = '';
      img.style.cssText = [
        'width:22px',
        'height:22px',
        'margin-right:5px',
        'vertical-align:middle',
        'display:inline-block',
      ].join(';');
      link.appendChild(img);
    }

    // Text
    var span         = document.createElement('span');
    span.style.cssText = 'line-height:22px;vertical-align:middle;font-size:22px;';
    span.textContent = 'Get Image';

    link.appendChild(span);
    wrapper.appendChild(link);
    return wrapper;
  }

  // ─── Inject / update / remove button theo URL hiện tại ────────────────────
  function updateButton() {
    var url      = window.location.href;
    var existing = document.getElementById(BUTTON_ID);

    if (urlHasImage(url)) {
      if (!existing && document.body) {
        document.body.appendChild(buildButton());
      }
    } else {
      if (existing) existing.remove();
    }
  }

  // ─── SPA navigation watcher — continuous interval ────────────────────────
  // Interval chạy liên tục mỗi 300ms, chỉ gọi updateButton() khi URL thay đổi.
  // Đây là cách đáng tin cậy nhất với Google Maps SPA trên mọi trình duyệt.
  var _watchedHref = window.location.href;

  setInterval(function () {
    var href = window.location.href;
    if (href !== _watchedHref) {
      _watchedHref = href;
      updateButton();
    }
  }, 300);

  // ─── Entry point ──────────────────────────────────────────────────────────
  var hostname = window.location.hostname;

  if (/downloadmapimage\.com/i.test(hostname)) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', runOnDownloadSite);
    } else {
      runOnDownloadSite();
    }

  } else if (/google\.com/i.test(hostname)) {
    // Chạy ngay lập tức + retry để đảm bảo Maps đã load đủ DOM
    if (document.body) {
      updateButton();
    } else {
      document.addEventListener('DOMContentLoaded', updateButton);
    }
    // Retry sau 500ms và 1500ms — phòng Maps lazy-load chậm trên Opera
    setTimeout(updateButton, 500);
    setTimeout(updateButton, 1500);
  }

})();
